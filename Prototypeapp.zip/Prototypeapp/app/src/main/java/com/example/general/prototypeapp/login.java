package com.example.general.prototypeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class login extends AppCompatActivity implements View.OnClickListener {
    private button login, Register;
    private EditText etName, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = (Button)FindViewByID(R.id.btnLogin);
        Register = (Button)FindViewByID(R.id.btnRegister);
        etName = (EditText)FindViewByID(R.id.txtName);
        etPassword = (EditText)FindViewByID(R.id.txtPassword);
        login.SetOnclickListener(This);
        Regiter.SetOnclickListener(This);


        }
    @Override
    public void onClick(View v){
switch(v.getId()){
    case R.id.btnLogin:
        break;
    case R.id.btnRegister:
        break;
    default:
}

    }
    }

